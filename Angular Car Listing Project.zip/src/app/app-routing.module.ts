import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarsDetailsComponent } from "./cars-details/cars-details.component";
import { CarsOnSaleComponent } from "./cars-on-sale/cars-on-sale.component";
import { WelcomeComponent } from "./welcome/welcome.component";






const routes: Routes = [
  { path: 'Home', component:  WelcomeComponent},
  { path: 'CarSale', component: CarsOnSaleComponent },
  { path: 'Details/:id', component:  CarsDetailsComponent},  
  { path: '', redirectTo:"/Home", pathMatch:"full" },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
