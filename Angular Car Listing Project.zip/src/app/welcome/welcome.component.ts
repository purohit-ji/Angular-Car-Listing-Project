import { Component, OnInit } from '@angular/core';
import  carJsonData  from "../files/car.json";

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  public myCarjsonData : {id:number,name:string,make:string,year:number,Description:string,price:string,img:string}[] = carJsonData;

  constructor() { 
   
  }

  ngOnInit() {
  }

}
