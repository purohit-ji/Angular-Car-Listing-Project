import { Component, OnInit } from '@angular/core';
import  carJsonData  from "../files/car.json";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-cars-details',
  templateUrl: './cars-details.component.html',
  styleUrls: ['./cars-details.component.css']
})
export class CarsDetailsComponent implements OnInit {
  public myCarjsonData : {id:number,name:string,make:string,year:number,Description:string,price:string,img:string}[] = carJsonData;

  public id: string;

constructor(private route: ActivatedRoute) {}

ngOnInit() {
   this.id = this.route.snapshot.paramMap.get('id');
    // this.myCarjsonData.forEach(element => {
    //   console.log(element['id']);
    // });
   
}

}
