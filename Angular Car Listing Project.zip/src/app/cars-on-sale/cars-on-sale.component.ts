import { Component, OnInit } from '@angular/core';
import  carJsonData  from "../files/car.json";

@Component({
  selector: 'app-cars-on-sale',
  templateUrl: './cars-on-sale.component.html',
  styleUrls: ['./cars-on-sale.component.css']
})
export class CarsOnSaleComponent implements OnInit {
  public myCarjsonData : {id:number,name:string,make:string,year:number,Description:string,price:string,img:string}[] = carJsonData;

  constructor() { }

  ngOnInit() {
  }

}
